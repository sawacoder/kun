from django.shortcuts import render
from django.shortcuts import render, redirect
# Create your views here.
from django.views.decorators.http import require_POST, require_safe
from .models import Contact, Phone
from contants import Phonetype


@require_safe
def contact_list_page(request):
    content = Contact.objects.all()
    return render(request, 'list.html', {'contacts': content})


def home(request):
    return render(request, 'index.html',{})


@require_safe
def details(request):
    return None


@require_safe
def create_page(request):
    choises = Phonetype.proccess()
    return render(request, "create.html", {'choises': choises})


@require_POST
def create(request):
    return None


@require_safe
def delete(request):
    return None


@require_POST
def delete_page(request):
    return None
