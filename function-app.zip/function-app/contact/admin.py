from django.contrib import admin
from .models import Contact, Phone

# Register your models here.


admin.site.register(Contact)
admin.site.register(Phone)
