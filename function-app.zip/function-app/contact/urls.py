from django.urls import path
from .views import (contact_list_page,
                    details,
                    create_page,
                    create,
                    delete,
                    delete_page)
app_name = 'contact'
urlpatterns = [
    path('list/', contact_list_page, name='contact'),
    path('details/<int:pk>/', details, name='detail'),
    path('create_page/', create_page, name='create_page'),
    path('create/', create, name='create'),
    path('delete/', delete, name='delete'),
    path('delete_page/', delete_page, name='delete_page'),

]
